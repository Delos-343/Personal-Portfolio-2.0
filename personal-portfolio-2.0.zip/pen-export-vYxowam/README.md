# Personal Portfolio 2.0 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/vYxowam](https://codepen.io/Delos_343/pen/vYxowam).

